#include <bits/stdc++.h>
#include <cmath>

using namespace std;
#pragma once

int main() {

  cout << atan2(1, 1) << endl;
  cout << atan2(1, -1) << endl;
  cout << atan2(-1, 1) << endl;
  cout << atan2(-1, -1) << endl;

  return 0;
}