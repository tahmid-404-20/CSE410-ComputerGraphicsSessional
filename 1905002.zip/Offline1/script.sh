# g++ rolling_ball.cpp -o ball.out -lglut -lGLU -lGL -O3
# ./ball.out

# g++ magic_cube.cpp -o cube.out -lglut -lGLU -lGL -O3
# ./cube.out


# g++ onlineA2.cpp -o cube.out -lglut -lGLU -lGL -O3
# ./cube.out

g++ online.cpp -o cube.out -lglut -lGLU -lGL -O3
./cube.out